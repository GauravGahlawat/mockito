package com.niit.mockito;

public interface Demo {

	String HELLO_WORLD = "Hello World";
	String greet();
}
